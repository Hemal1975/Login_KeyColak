import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PermissionGuard } from '../app/core/model/permission-guard';
import { AuthGuardService as AuthGuard } from '../app/core/guard/auth-guard.service';
import { HomeComponent } from './home/home.component';



export const routes: Routes = [
	{ path: '', redirectTo: 'home', pathMatch: 'full' },
	{ path: 'home', component: HomeComponent },
	{
		path: 'groupRestricted',
		canLoad: [AuthGuard],
		loadChildren: 'app/group-restricted/group-restricted.module#GroupRestrictedModule',
		data: {
			Permission: {
				Only: ['User'],
				RedirectTo: '403'
			} as PermissionGuard
		}
	},

	{ path: '**', redirectTo: '404' }
];

@NgModule({
	imports: [RouterModule.forRoot(routes)],
	exports: [RouterModule]
})
export class AppRoutingModule { }
